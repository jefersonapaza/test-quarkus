package pe.com.mibanco.base.bs.application.impl;

import jakarta.enterprise.context.ApplicationScoped;
import pe.com.mibanco.base.bs.application.PersonaService;

/*
 * class service example
 */
@ApplicationScoped
public class PersonaServiceImpl implements PersonaService {

}