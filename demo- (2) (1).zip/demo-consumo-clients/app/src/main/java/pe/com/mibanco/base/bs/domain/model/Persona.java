package pe.com.mibanco.base.bs.domain.model;

/*
 * class model example
 */
public class Persona{

}