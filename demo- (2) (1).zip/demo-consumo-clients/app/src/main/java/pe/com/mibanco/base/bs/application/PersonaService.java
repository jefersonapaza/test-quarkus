package pe.com.mibanco.base.bs.application;


/*
 * class service example
 */
public interface PersonaService {

}