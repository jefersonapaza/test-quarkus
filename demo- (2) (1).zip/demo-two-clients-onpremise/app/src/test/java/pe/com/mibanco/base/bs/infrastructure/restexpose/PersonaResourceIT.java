package pe.com.mibanco.base.bs.infrastructure.restexpose;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class PersonaResourceIT extends PersonaResourceTest {
    // Execute the same tests but in packaged mode.
}
