package pe.com.mibanco.base.bs.infrastructure.config;

import jakarta.enterprise.context.ApplicationScoped;

/*
 * class configuration example
 */
@ApplicationScoped
public class PersonaConfiguration {

}