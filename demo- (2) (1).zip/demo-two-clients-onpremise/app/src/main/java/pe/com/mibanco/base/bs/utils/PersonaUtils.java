package pe.com.mibanco.base.bs.utils;

import jakarta.enterprise.context.ApplicationScoped;


/*
 * class utility example
 */
@ApplicationScoped
public class PersonaUtils {

}
